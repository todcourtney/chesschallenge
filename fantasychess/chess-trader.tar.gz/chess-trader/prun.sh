export CHESS_GATEWAY=hornet1
export PATH=/home/usaco35/stockfish-dd-src/src:$PATH
export PYTHONPATH=common:strat:ChessBoard:c++/swig
python strat/examples.py SCO SCS SCM SIMM M2M
